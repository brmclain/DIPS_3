from cv2 import namedWindow, imshow, waitKey, imwrite, imread
from cv2 import putText, LINE_AA, FONT_HERSHEY_SIMPLEX

from numpy import zeros, ones, array, shape, arange
from numpy import random
from numpy import min, max, sqrt, sum
from numpy import uint8
from numpy import inf
from numpy.fft import fft2