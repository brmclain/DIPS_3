from .interpolation import interpolation
from dip import *
"""
Do not import cv2, numpy and other third party libs
"""


class Geometric:
    def __init__(self):
        pass

    def forward_rotate(self, image, theta):
        """Computes the forward rotated image by an angle theta
                image: input image
                theta: angle to rotate the image by (in radians)
                return the rotated image"""
        import math
        y = image.shape[1]
        x = image.shape[0]
        
        topleft = [0,0]
        topright = [0-y*math.sin(theta),
                    y*math.cos(theta)]
        bottomleft = [x*math.cos(theta),
                      x*math.sin(theta)]
        bottomright = [x*math.cos(theta)-y*math.sin(theta),
                       x*math.sin(theta)+y*math.cos(theta)]
        
        minx = int(round(min([topleft[0], topright[0], bottomleft[0], bottomright[0]])))
        maxx = int(round(max([topleft[0], topright[0], bottomleft[0], bottomright[0]])))
        miny = int(round(min([topleft[1], topright[1], bottomleft[1], bottomright[1]])))
        maxy = int(round(max([topleft[1], topright[1], bottomleft[1], bottomright[1]])))
        rows = maxx - minx
        cols = maxy - miny
        
        temp = zeros((rows, cols))
        
        for i in range(x):
            for j in range(y):
                roti = int(round(i*math.cos(theta)-j*math.sin(theta)))
                rotj = int(round(i*math.sin(theta)+j*math.cos(theta)))
                roti = roti - minx
                rotj = rotj - miny
                temp[roti][rotj] = image[i][j]
        image = temp
        return image

    def reverse_rotation(self, rotated_image, theta, origin, original_shape):
        """Computes the reverse rotated image by an angle theta
                rotated_image: the rotated image from previous step
                theta: angle to rotate the image by (in radians)
                Origin: origin of the original image with respect to the rotated image
                Original shape: Shape of the orginal image
                return the original image"""
        import math
        image = zeros(original_shape)
        for iteratej in range(len(rotated_image)):
            for iteratei in range(len(rotated_image[0])):
                i = iteratei - origin[0]
                j = iteratej - origin[1]
                oldi = int(round(i*math.cos(theta)+j*math.sin(theta)))
                oldj = int(round(i*-1*math.sin(theta)+j*math.cos(theta)))
                if (oldi >= 0 and oldi < original_shape[0]) and (oldj >= 0 and oldj < original_shape[1]):
                    image[oldi][oldj] = rotated_image[iteratei][iteratej]
       
        return image

    def rotate(self, image, theta, interpolation_type):
        """Computes the rotated image by an angle theta and perfrom interpolation
                image: the input image
                theta: angle to rotate the image by (in radians)
                interpolation_type: type of interpolation to use (nearest_neighbor, bilinear)
                return the rotated image"""

        rotated_image = self.forward_rotate(image, theta)

        import math
        y = image.shape[1]
        x = image.shape[0]
    
        topleft = [0,0]
        topright = [0-y*math.sin(theta),
                    y*math.cos(theta)]
        bottomleft = [x*math.cos(theta),
                    x*math.sin(theta)]
        bottomright = [x*math.cos(theta)-y*math.sin(theta),
                    x*math.sin(theta)+y*math.cos(theta)]
        
        minx = int(round(min([topleft[0], topright[0], bottomleft[0], bottomright[0]])))
        maxx = int(round(max([topleft[0], topright[0], bottomleft[0], bottomright[0]])))
        miny = int(round(min([topleft[1], topright[1], bottomleft[1], bottomright[1]])))
        maxy = int(round(max([topleft[1], topright[1], bottomleft[1], bottomright[1]])))
        rows = maxx - minx
        cols = maxy - miny
        
        rotated_image = zeros((rows, cols))
        origin = [-minx, -miny]
        
        for iteratej in range(len(rotated_image)):
            for iteratei in range(len(rotated_image[0])):
                i = iteratei - origin[0]
                j = iteratej - origin[1]
                oldi = i*math.cos(theta)+j*math.sin(theta)
                oldj = i*-1*math.sin(theta)+j*math.cos(theta)
                if (oldi >= 1 and oldi < x-1) and (oldj >= 1 and oldj < y-1):
                    #image[oldi][oldj] = rotated_image[iteratei][iteratej]
                    if interpolation_type == "nearest_neighbor":
                        rotated_image[iteratei][iteratej] = image[int(round(oldi))][int(round(oldj))]
                    elif interpolation_type == "bilinear":
                        x1 = int(math.floor(oldi))
                        x2 = int(math.ceil(oldi))
                        y1 = int(math.floor(oldj))
                        y2 = int(math.ceil(oldj))
                        rotated_image[iteratei][iteratej] = interpolation.bilinear_interpolation([oldi, oldj],
                                                                                                 [x1, y1],
                                                                                                 [x1, y2],
                                                                                                 [x2, y1],
                                                                                                 [x2, y2],
                                                                                                 image[x1, y1],
                                                                                                 image[x1, y2],
                                                                                                 image[x2, y1],
                                                                                                 image[x2, y2])
                    

                    
        return rotated_image


